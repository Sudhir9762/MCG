import * as XLSX from 'xlsx';
import { Contact } from '../types';

// Helper to check if string looks like a phone number
const isPhoneLike = (cell: any): boolean => {
  if (!cell) return false;
  const str = String(cell).trim();
  // Check if it has enough digits to be a phone number
  const digits = str.replace(/\D/g, '');
  // A very loose check: at least 6 digits. 
  // Real numbers are 10+, but we want to detect the column even if some are short/malformed.
  return digits.length >= 6;
};

// Helper to check if string looks like a name
const isNameLike = (cell: any): boolean => {
  if (!cell) return false;
  const str = String(cell).trim();
  // If it looks like a phone number, it's not a name
  if (isPhoneLike(str)) return false;
  // If it has an @ symbol, it's likely an email, not a name
  if (str.includes('@')) return false;
  // Should contain letters
  return /[a-zA-Z]/.test(str);
};

const detectColumns = (data: any[][]): { nameIndex: number, numberIndex: number } => {
  if (!data || data.length === 0) return { nameIndex: 0, numberIndex: 1 };

  // Analyze a sample of rows (first 50)
  const sample = data.slice(0, 50);
  const colStats: Record<number, { phoneScore: number; nameScore: number; count: number }> = {};

  sample.forEach(row => {
    if (!Array.isArray(row)) return;
    row.forEach((cell, idx) => {
      if (!colStats[idx]) colStats[idx] = { phoneScore: 0, nameScore: 0, count: 0 };
      colStats[idx].count++;
      
      if (isPhoneLike(cell)) {
        colStats[idx].phoneScore++;
      } else if (isNameLike(cell)) {
        colStats[idx].nameScore++;
      }
    });
  });

  let bestPhoneIdx = -1;
  let bestPhoneScoreVal = 0;

  // Identify phone column: looking for highest density of phone-like values
  Object.keys(colStats).forEach((key) => {
    const idx = Number(key);
    const stats = colStats[idx];
    const score = stats.count > 0 ? stats.phoneScore / stats.count : 0;
    
    // Threshold: at least 40% of rows look like phone numbers
    if (score > 0.4 && score > bestPhoneScoreVal) {
      bestPhoneScoreVal = score;
      bestPhoneIdx = idx;
    }
  });

  // Identify name column: looking for highest density of name-like values
  let bestNameIdx = -1;
  let bestNameScoreVal = 0;

  Object.keys(colStats).forEach((key) => {
    const idx = Number(key);
    // Name column cannot be the same as the phone column
    if (idx === bestPhoneIdx) return;

    const stats = colStats[idx];
    const score = stats.count > 0 ? stats.nameScore / stats.count : 0;

    // Threshold: at least 40% of rows look like names
    if (score > 0.4 && score > bestNameScoreVal) {
      bestNameScoreVal = score;
      bestNameIdx = idx;
    }
  });

  // Fallbacks if detection fails
  if (bestPhoneIdx === -1) bestPhoneIdx = 1; // Default to Column B
  if (bestNameIdx === -1) bestNameIdx = 0;   // Default to Column A
  
  // Last resort safety: if they are same, force differ
  if (bestNameIdx === bestPhoneIdx) {
      bestNameIdx = bestPhoneIdx === 0 ? 1 : 0;
  }

  return { nameIndex: bestNameIdx, numberIndex: bestPhoneIdx };
};

export const parseExcelFile = async (file: File): Promise<Contact[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        // Convert to JSON (array of arrays) to easily map columns
        const jsonData = XLSX.utils.sheet_to_json<any[]>(worksheet, { header: 1 });
        
        const { nameIndex, numberIndex } = detectColumns(jsonData);
        console.log(`Auto-detected columns - Name: Col ${nameIndex}, Number: Col ${numberIndex}`);

        const contacts: Contact[] = jsonData.map((row, index) => {
          const rawName = row[nameIndex] ? String(row[nameIndex]).trim() : '';
          const rawNumber = row[numberIndex] ? String(row[numberIndex]).trim() : '';
          
          // Skip completely empty rows
          if (!rawName && !rawNumber) return null;

          // Clean number: remove non-digits
          const cleanedNumber = rawNumber.replace(/\D/g, '');
          const isValid = cleanedNumber.length >= 10 && rawName.length > 0;

          return {
            id: `row-${index}`,
            originalName: rawName,
            originalNumber: rawNumber,
            cleanedNumber,
            isValid
          };
        }).filter((c): c is Contact => c !== null);

        resolve(contacts);
      } catch (error) {
        reject(error);
      }
    };

    reader.onerror = (error) => reject(error);
    reader.readAsArrayBuffer(file);
  });
};

export const generateVCFContent = (contacts: Contact[], prefix: string): string => {
  let vcfString = '';

  contacts.forEach(contact => {
    if (!contact.isValid) return;

    const fullName = `${prefix}${contact.originalName}`.trim();
    
    vcfString += 'BEGIN:VCARD\n';
    vcfString += 'VERSION:3.0\n';
    vcfString += `FN:${fullName}\n`;
    vcfString += `N:;${fullName};;;\n`;
    vcfString += `TEL;TYPE=CELL:${contact.cleanedNumber}\n`;
    vcfString += 'END:VCARD\n';
  });

  return vcfString;
};

export const downloadVCF = (content: string, filename: string) => {
  const blob = new Blob([content], { type: 'text/vcard' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};