import React, { useState, useMemo, useEffect } from 'react';
import { Dropzone } from './components/Dropzone';
import { PreviewTable } from './components/PreviewTable';
import { parseExcelFile, generateVCFContent, downloadVCF } from './utils/excelParser';
import { suggestPrefix } from './services/geminiService';
import { Contact, Step } from './types';
import { 
  FileCheck, 
  Settings, 
  Download, 
  ArrowRight, 
  RefreshCcw, 
  Sparkles, 
  Trash2,
  Users,
  CheckCircle2,
  Phone
} from 'lucide-react';

const App: React.FC = () => {
  const [step, setStep] = useState<Step>(Step.UPLOAD);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [prefix, setPrefix] = useState('');
  const [isSuggesting, setIsSuggesting] = useState(false);
  const [fileName, setFileName] = useState('contacts');

  const stats = useMemo(() => {
    return {
      total: contacts.length,
      valid: contacts.filter(c => c.isValid).length,
      invalid: contacts.filter(c => !c.isValid).length
    };
  }, [contacts]);

  const handleFileSelect = async (file: File) => {
    setIsLoading(true);
    try {
      const parsedContacts = await parseExcelFile(file);
      setContacts(parsedContacts);
      setFileName(file.name.replace(/\.[^/.]+$/, ""));
      setStep(Step.PREVIEW);
    } catch (error) {
      console.error("Failed to parse file", error);
      alert("Error parsing file. Please ensure it is a valid Excel file.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownload = () => {
    const vcfContent = generateVCFContent(contacts, prefix);
    downloadVCF(vcfContent, `${fileName}_converted.vcf`);
    setStep(Step.DOWNLOAD);
  };

  const handleReset = () => {
    setContacts([]);
    setPrefix('');
    setStep(Step.UPLOAD);
  };

  const handleAiSuggest = async () => {
    setIsSuggesting(true);
    const validNames = contacts
      .filter(c => c.isValid && c.originalName)
      .map(c => c.originalName);
      
    if (validNames.length === 0) {
       alert("No valid names to analyze.");
       setIsSuggesting(false);
       return;
    }

    const suggestion = await suggestPrefix(validNames);
    if (suggestion) {
      setPrefix(suggestion);
    }
    setIsSuggesting(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 flex flex-col font-sans">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm z-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
             <div className="bg-indigo-600 p-2 rounded-lg shadow-sm">
               <Users className="text-white w-5 h-5" />
             </div>
             <div>
               <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-violet-600 leading-none">
                 Excel2VCF
               </h1>
               <p className="text-[10px] text-gray-500 font-medium leading-none mt-1 uppercase tracking-wide">
                 By Prof. Sudhirkumar N. Rathod
               </p>
             </div>
          </div>
          <div className="flex space-x-2">
             <div className={`h-2 w-2 rounded-full transition-colors duration-300 ${step === Step.UPLOAD ? 'bg-indigo-600' : 'bg-gray-300'}`}></div>
             <div className={`h-2 w-2 rounded-full transition-colors duration-300 ${step === Step.PREVIEW ? 'bg-indigo-600' : 'bg-gray-300'}`}></div>
             <div className={`h-2 w-2 rounded-full transition-colors duration-300 ${step === Step.DOWNLOAD ? 'bg-indigo-600' : 'bg-gray-300'}`}></div>
          </div>
        </div>
      </header>

      <main className="flex-grow w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Step 1: Upload */}
        {step === Step.UPLOAD && (
          <div className="animate-fade-in-up max-w-2xl mx-auto mt-12 text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 mb-4 tracking-tight">
              Convert Contact Lists Instantly
            </h2>
            <p className="text-lg text-gray-500 mb-10">
              Clean, format, and convert Excel spreadsheets into mobile-ready VCF cards.
              <br/>Only keeps valid numbers with 10+ digits.
            </p>
            <Dropzone onFileSelect={handleFileSelect} isLoading={isLoading} />
            {isLoading && (
              <div className="mt-8 flex items-center justify-center space-x-2 text-indigo-600">
                 <RefreshCcw className="animate-spin w-5 h-5" />
                 <span>Processing file...</span>
              </div>
            )}
          </div>
        )}

        {/* Step 2: Configure & Preview */}
        {step === Step.PREVIEW && (
          <div className="animate-fade-in space-y-8">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex items-center space-x-4">
                 <div className="p-3 bg-blue-50 rounded-full text-blue-600">
                    <FileCheck size={24} />
                 </div>
                 <div>
                    <p className="text-sm text-gray-500 font-medium">Total Rows</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
                 </div>
              </div>
              <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex items-center space-x-4">
                 <div className="p-3 bg-green-50 rounded-full text-green-600">
                    <CheckCircle2 size={24} />
                 </div>
                 <div>
                    <p className="text-sm text-gray-500 font-medium">Valid Contacts</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.valid}</p>
                 </div>
              </div>
              <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex items-center space-x-4">
                 <div className="p-3 bg-red-50 rounded-full text-red-600">
                    <Trash2 size={24} />
                 </div>
                 <div>
                    <p className="text-sm text-gray-500 font-medium">Ignored ({"<"}10 digits)</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.invalid}</p>
                 </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
               {/* Left: Configuration */}
               <div className="lg:col-span-1 space-y-6">
                  <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm sticky top-8">
                    <div className="flex items-center space-x-2 mb-6">
                      <Settings className="text-gray-400 w-5 h-5" />
                      <h3 className="text-lg font-bold text-gray-900">Configuration</h3>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Prefix to add to name
                        </label>
                        <p className="text-xs text-gray-500 mb-2">
                          Useful for grouping contacts (e.g. "Work - ").
                        </p>
                        <div className="flex space-x-2">
                          <input
                            type="text"
                            value={prefix}
                            onChange={(e) => setPrefix(e.target.value)}
                            placeholder="e.g. Client - "
                            className="flex-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2.5 border"
                          />
                        </div>
                        
                        {/* AI Suggestion */}
                        <button
                          onClick={handleAiSuggest}
                          disabled={isSuggesting}
                          className="mt-3 w-full flex items-center justify-center space-x-2 text-xs font-medium text-indigo-600 bg-indigo-50 hover:bg-indigo-100 p-2 rounded-md transition-colors"
                        >
                          {isSuggesting ? (
                             <RefreshCcw className="w-3 h-3 animate-spin" />
                          ) : (
                             <Sparkles className="w-3 h-3" />
                          )}
                          <span>
                            {isSuggesting ? 'Thinking...' : 'AI Suggest Prefix'}
                          </span>
                        </button>
                      </div>

                      <div className="pt-4 border-t border-gray-100">
                         <p className="text-xs text-gray-500 mb-2">
                           Review the "Preview Name" column in the table to see how contacts will look.
                         </p>
                      </div>

                      <button
                        onClick={handleDownload}
                        disabled={stats.valid === 0}
                        className="w-full flex items-center justify-center space-x-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-4 rounded-lg shadow-md transition-transform active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                         <Download size={20} />
                         <span>Download VCF</span>
                      </button>
                      
                      <button
                         onClick={handleReset}
                         className="w-full text-sm text-gray-500 hover:text-gray-700 underline"
                      >
                        Upload a different file
                      </button>
                    </div>
                  </div>
               </div>

               {/* Right: Table */}
               <div className="lg:col-span-2">
                  <PreviewTable contacts={contacts} prefix={prefix} />
               </div>
            </div>
          </div>
        )}

        {/* Step 3: Success State */}
        {step === Step.DOWNLOAD && (
           <div className="animate-fade-in max-w-md mx-auto mt-20 text-center p-8 bg-white rounded-2xl shadow-lg border border-gray-100">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 className="w-10 h-10 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Success!</h2>
              <p className="text-gray-500 mb-8">
                Your VCF file has been generated and downloaded. You can now import it into your phone or email client.
              </p>
              
              <button
                onClick={handleReset}
                className="inline-flex items-center space-x-2 text-indigo-600 font-medium hover:text-indigo-800"
              >
                <span>Convert another file</span>
                <ArrowRight size={16} />
              </button>
           </div>
        )}

      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-8 mt-auto">
        <div className="max-w-6xl mx-auto px-4 flex flex-col items-center justify-center text-center space-y-3">
           <p className="text-sm text-gray-500 tracking-wide uppercase font-semibold">Designed & Generated by</p>
           <h3 className="text-xl font-bold text-gray-900">Prof. Sudhirkumar N. Rathod</h3>
           <a href="tel:+917972292310" className="inline-flex items-center space-x-2 text-indigo-600 font-semibold bg-indigo-50 hover:bg-indigo-100 px-5 py-2 rounded-full transition-colors">
             <Phone size={18} />
             <span>+91 79722 92310</span>
           </a>
        </div>
      </footer>
    </div>
  );
};

export default App;